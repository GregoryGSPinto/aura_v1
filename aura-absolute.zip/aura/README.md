# 🌟 Aura — Autonomous Personal AI Agent

> **"AI should reclaim time for family and quality of life, not increase productivity output."**

Aura is a production-grade autonomous AI agent built on a **pluggable three-layer architecture** that separates reasoning, execution, and governance into independently swappable modules.

**Brain** (Claude API) thinks. **Body** (OpenClaw) acts. **Aura Core** governs — enforcing autonomy levels, managing persistent memory, controlling costs, and ensuring resilience.

## Architecture

```
┌─────────────────────────────────────────────┐
│              INTERFACES (Plugin)             │
│       Web · Mobile · Desktop · Voice         │
└──────────────────┬──────────────────────────┘
                   │
┌──────────────────▼──────────────────────────┐
│             AURA CORE (Permanent)            │
│                                              │
│  ┌──────────┐ ┌──────────┐ ┌──────────────┐ │
│  │ Autonomy │ │  Memory  │ │ Token Budget │ │
│  │  Guard   │ │  Engine  │ │   Manager    │ │
│  └──────────┘ └──────────┘ └──────────────┘ │
│  ┌──────────┐ ┌──────────┐ ┌──────────────┐ │
│  │  Event   │ │  Circuit │ │  Structured  │ │
│  │   Bus    │ │ Breakers │ │    Logger    │ │
│  └──────────┘ └──────────┘ └──────────────┘ │
└───────┬─────────────────────────┬───────────┘
        │                         │
┌───────▼───────┐       ┌────────▼──────────┐
│  BRAIN        │       │  BODY             │
│  (Plugin)     │       │  (Plugin)         │
│               │       │                   │
│  Claude API   │       │  OpenClaw         │
│  via IBrain   │       │  via IBody        │
└───────────────┘       └───────────────────┘
```

### Design Principles

| Principle | Implementation |
|-----------|---------------|
| **Pluggability over lock-in** | `IBrain` and `IBody` contracts — swap LLM or executor without losing memory |
| **Memory sovereignty** | All data lives in Aura Core. Brain and Body are stateless consumers |
| **Autonomy with guardrails** | L3 actions are hardcoded blocked — not configurable, not promotable |
| **Cost awareness** | Token budget with auto-downgrade prevents runaway API spend |
| **Resilience by default** | Circuit breakers, retry with backoff, graceful degradation |
| **Observable operations** | Structured JSON logs, correlation IDs, health checks, event bus |

## Autonomy Levels

| Level | Name | Behavior | Examples |
|-------|------|----------|----------|
| **L1** | Autonomous | Executes without asking | Research, analysis, organization |
| **L2** | Approval Required | Queues for voice/tap approval | Send email, apply for job, schedule meeting |
| **L3** | Blocked (Hardcoded) | Rejected immediately. Cannot be promoted. Ever. | Financial transfers, legal signing, credential changes, public posts |

```typescript
// L3 is hardcoded. This throws AutonomyViolationError:
guard.promote('financial_transfer', 'I want auto-payments');
// => SECURITY VIOLATION: Cannot promote L3 action. L3 is HARDCODED.
```

## Token Budget Tiers

| Tier | Threshold | Behavior |
|------|-----------|----------|
| 🟢 Green | < 70% | Normal operation, preferred model |
| 🟡 Yellow | 70-90% | Warning logged, auto-downgrade to cheaper model |
| 🔴 Red | 90-100% | Critical — only essential actions, user notified |
| ⛔ Blocked | > 100% | All API calls stopped, cached responses only |

## Project Structure

```
aura/
├── packages/
│   ├── aura-core/              # Governance + Memory + Guards
│   │   └── src/
│   │       ├── interfaces.ts   # Sacred contracts (IBrain, IBody, IAura)
│   │       ├── aura.ts         # Main orchestrator
│   │       ├── autonomy-guard.ts
│   │       ├── memory-engine.ts
│   │       ├── token-budget.ts
│   │       ├── event-bus.ts
│   │       ├── logger.ts
│   │       ├── patterns/
│   │       │   ├── circuit-breaker.ts
│   │       │   └── retry.ts
│   │       └── __tests__/
│   │           └── autonomy-guard.test.ts
│   ├── aura-brain-claude/      # Claude API plugin
│   ├── aura-body-openclaw/     # OpenClaw executor plugin
│   └── aura-web/               # Web interface (Vite + React)
├── docs/
│   └── adrs/                   # Architecture Decision Records
│       ├── 001-pluggable-architecture.md
│       ├── 002-memory-engine-schema.md
│       ├── 003-autonomy-guard.md
│       ├── 005-error-handling.md
│       └── 006-token-economics.md
└── package.json                # Monorepo (npm workspaces)
```

## Resilience

Every external dependency is wrapped in a **Circuit Breaker** with **exponential backoff retry**:

```
CLOSED ──── 3 failures ──→ OPEN (30s cooldown)
                              │
                         half-open test
                              │
                    success → CLOSED
                    failure → OPEN (retry later)
```

**Graceful degradation matrix:**
- Brain fails → respond from cache, suggest retry
- Body fails → queue actions, execute when recovered
- Memory fails → operate without context, warn user
- Budget exceeded → auto-downgrade model, then stop

## Observability

- **Structured JSON logs** — parseable by any log aggregator
- **Correlation IDs** — every request gets a UUID; grep it for full timeline
- **Event Bus** — decoupled pub/sub for cross-component communication
- **Health endpoint** — brain status, body status, memory stats, budget, circuit breaker states

## Architectural Decision Records

| ADR | Title | Summary |
|-----|-------|---------|
| 001 | Pluggable Architecture | Three-layer design with interface contracts |
| 002 | Memory Engine Schema | SQLite now, PostgreSQL later — same interface |
| 003 | Autonomy Guard | Three levels with hardcoded L3 blocks |
| 005 | Error Handling | Circuit breakers, retry, graceful degradation |
| 006 | Token Economics | Budget tiers with auto-downgrade |

## Roadmap

| Phase | Milestone | Status |
|-------|-----------|--------|
| 0 | Foundation — ADRs, monorepo, contracts | ✅ Complete |
| 1 | Core + Voice — web app with voice commands | 🔄 In Progress |
| 2 | Integration — Claude Brain + OpenClaw Body connected | Planned |
| 3 | Mobile — iOS/Android app | Planned |
| 4 | Scale — dedicated server, smart glasses, custom hardware | Vision |

## Tech Stack

- **Language:** TypeScript (strict mode)
- **Runtime:** Node.js 22+
- **Database:** SQLite (→ PostgreSQL in Phase 4)
- **Brain:** Anthropic Claude API (Sonnet 4 default)
- **Body:** OpenClaw (open-source autonomous agent)
- **Frontend:** React + Vite
- **Voice:** Web Speech API (→ Whisper in Phase 4)
- **Testing:** Vitest
- **Deployment:** Vercel (web) / Docker (server)

## Philosophy

> Aura is not a productivity tool. Aura is a **liberation tool**.
>
> Every feature is evaluated against one question:
> *"Does this give time back to the user, or does it create more work?"*
>
> The Industrial Revolution promised liberation but increased workload.
> AI must not repeat that mistake.

---

**Author:** Gregory — AI Solution Architect
**License:** UNLICENSED (Private)
